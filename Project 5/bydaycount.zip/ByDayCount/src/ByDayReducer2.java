import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ByDayReducer2 extends Reducer<Text, CompositeKey2 , Text, CompositeKey2> {

  @Override
  public void reduce(Text key, Iterable<CompositeKey2> values, Context context)
      throws IOException, InterruptedException {

	  CompositeKey2 value;
	  for(CompositeKey2 val: values){
		  value = val;
		  context.write( key , value );
		  break;
	  }
    
    
    
  }
}