import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapreduce.Mapper;

public  class CompositeKey2 implements WritableComparable<CompositeKey2> {
	
	
	Text ip;
	IntWritable count;

	public CompositeKey2(){
		ip = new Text();
		count = new IntWritable();
	}
	
	public CompositeKey2(Text ip, IntWritable count){
		this.ip = ip;
		this.count = count;
	}
	
	public CompositeKey2(String ip, int count){
		this.ip = new Text(ip);
		this.count = new IntWritable( count);
	}
	
	public void write(DataOutput out) throws IOException {
		ip.write(out);
		count.write(out);
	}

	public void readFields(DataInput in) throws IOException {
		ip.readFields(in);
		count.readFields(in);
	}
	
	
	public int compareTo(CompositeKey2 pop) {
 
        return -1 * count.compareTo(pop.count);
	}
	
	
	@Override
	public String toString() {
		return ip.toString() + " " + count.toString();
	}


}