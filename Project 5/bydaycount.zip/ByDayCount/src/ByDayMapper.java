import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 * Example input line:
 * 96.7.4.14 - - [24/Apr/2011:04:20:11 -0400] "GET /cat.jpg HTTP/1.1" 200 12433
 *
 */
public class ByDayMapper extends Mapper<LongWritable, Text, CompositeKey, IntWritable> {

  @Override
  public void map(LongWritable key, Text value, Context context)
      throws IOException, InterruptedException {

    /*
     * Split the input line into space-delimited fields.
     */
    String[] fields = value.toString().split(" ");
    if (fields.length > 2) {

      String ip = fields[0];
      String time = fields[3];
      String fields2[] = time.split("\\W+");
      String date = fields2[1] +"/" + fields2[2] +"/" + fields2[3]; 
      
      context.write(new CompositeKey(date,ip), new IntWritable(1));
    }
  }
}