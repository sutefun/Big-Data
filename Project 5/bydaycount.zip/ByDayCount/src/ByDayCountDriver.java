import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class ByDayCountDriver {

  public static void main(String[] args) throws Exception {

    /*
     * Validate that two arguments were passed from the command line.
     */
    if (args.length != 2) {
      System.out.printf("Usage: ByDayCount <input dir> <output dir>\n");
      System.exit(-1);
    }

    /*
     * Instantiate a Job object for your job's configuration. 
     */
    Job job = new Job();
    
    /*
     * Specify the jar file that contains your driver, mapper, and reducer.
     * Hadoop will transfer this jar file to nodes in your cluster running 
     * mapper and reducer tasks.
     */
    job.setJarByClass(ByDayCountDriver.class);
    
    /*
     * Specify an easily-decipherable name for the job.
     * This job name will appear in reports and logs.
     */
    job.setJobName("Stub Driver");

    FileInputFormat.addInputPath(job, new Path(args[0]) );
    FileOutputFormat.setOutputPath(job, new Path(args[0]+"temp")  );
    
    job.setMapperClass(ByDayMapper.class);
    job.setCombinerClass(ByDayCombiner.class);
    job.setReducerClass(ByDayReducer.class);
    job.setNumReduceTasks(1);
    job.setOutputKeyClass(CompositeKey.class);
    job.setOutputValueClass(IntWritable.class);
    
    /*
     * Start the MapReduce job and wait for it to finish.
     * If it finishes successfully, return 0. If not, return 1.
     */
    boolean success = job.waitForCompletion(true);
    
    
    Job job2 = new Job(); 
    job2.setJarByClass(ByDayCountDriver.class);
    job2.setMapperClass(ByDayMapper2.class);
    job2.setReducerClass(ByDayReducer2.class);;
    job2.setMapOutputKeyClass(Text.class);
    job2.setMapOutputValueClass(CompositeKey2.class);
    job2.setNumReduceTasks(1);

    FileInputFormat.addInputPath(job2, new Path(args[0]+"temp") );
    FileOutputFormat.setOutputPath(job2, new Path(args[1])  );
    
    success = job2.waitForCompletion(true);
    FileSystem fs = FileSystem.get(new Configuration());
    // true stands for recursively deleting the folder you gave
    fs.delete(new Path(args[0]+"temp"), true);
    
    
    System.exit(success ? 0 : 1);
  }
}

