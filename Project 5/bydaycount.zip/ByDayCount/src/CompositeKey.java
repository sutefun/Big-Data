import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapreduce.Mapper;

public  class CompositeKey implements WritableComparable<CompositeKey> {
	
	Text date;
	Text ip;

	public CompositeKey(){
		date = new Text();
		ip = new Text();
	}
	
	public CompositeKey(Text date, Text ip){
		this.date = date;
		this.ip = ip;
	}
	
	public CompositeKey(String date, String ip){
		this.date = new Text(date);
		this.ip = new Text( ip);
	}
	
	public void write(DataOutput out) throws IOException {
		date.write(out);
		ip.write(out);
	}

	public void readFields(DataInput in) throws IOException {
		date.readFields(in);
		ip.readFields(in);
	}
	
	
	public int compareTo(CompositeKey pop) {
		int cmp = date.compareTo(pop.date);
		 
        if (cmp != 0) {
            return cmp;
        }
 
        return ip.compareTo(pop.ip);
	}
	
	
	@Override
	public String toString() {
		return date.toString() + " " + ip.toString();
	}


}