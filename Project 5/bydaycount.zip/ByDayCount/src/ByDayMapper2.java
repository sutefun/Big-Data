import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 * Example input line:
 * 96.7.4.14 - - [24/Apr/2011:04:20:11 -0400] "GET /cat.jpg HTTP/1.1" 200 12433
 *
 */
public class ByDayMapper2 extends Mapper<LongWritable, Text, Text, CompositeKey2> {

  @Override
  public void map(LongWritable key, Text value, Context context)
      throws IOException, InterruptedException {

    /*
     * Split the input line into space-delimited fields.
     */
    String[] fields = value.toString().split("\\s+");
    if (fields.length > 2) {
      String date = fields[0];
      String ip = fields[1];
      
      try{

          int count = Integer.parseInt(fields[2]);
          context.write(new Text(date), new CompositeKey2(ip,count) );
      }
      catch(NumberFormatException nfe){}
    }
  }
}