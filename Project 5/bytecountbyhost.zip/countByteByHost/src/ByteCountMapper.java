import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.junit.Test;

public class ByteCountMapper extends Mapper<LongWritable, Text,  Text, LongWritable > {

  @Override
  public void map(LongWritable key, Text value, Context context)
      throws IOException, InterruptedException {

	  String[] fields = value.toString().split(" ");
	  
	  if(fields.length >3){
      	//get the last index  from the log line
	        String s = fields[fields.length - 1];
	        String s2 = fields[0];
	        try{
	        	Long count = Long.parseLong(s);
		  		LongWritable bytecount = new LongWritable( count );
		  		Text hostip = new Text(s2);
		  		//write context
				context.write(  hostip , bytecount  );
				
	        }catch (NumberFormatException nfe){
	        	
	        }
	        
      }

  }
}
