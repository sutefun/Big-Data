import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.map.InverseMapper;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class ByteCountDriver {

  public static void main(String[] args) throws Exception {

    /*
     * Validate that two arguments were passed from the command line.
     */
    if (args.length != 2) {
      System.out.printf("Usage: ByteCountByHost <input dir> <output dir>\n");
      System.exit(-1);
    }

    /*
     * Instantiate a Job object for your job's configuration. 
     */
    Job job = new Job();
    
    /*
     * Specify the jar file that contains your driver, mapper, and reducer.
     * Hadoop will transfer this jar file to nodes in your cluster running 
     * mapper and reducer tasks.
     */
    job.setJarByClass(ByteCountDriver.class);
    
    /*
     * Specify an easily-decipherable name for the job.
     * This job name will appear in reports and logs.
     */
    job.setJobName("ByteCount Driver");

    FileInputFormat.addInputPath(job, new Path(args[0]) );
    FileOutputFormat.setOutputPath(job, new Path(args[0]+"temp")  );
    
    job.setMapperClass(ByteCountMapper.class);
    job.setMapOutputKeyClass(Text.class);
    job.setMapOutputValueClass(LongWritable.class);
    job.setCombinerClass(ByteCountReducer.class);
    
   job.setReducerClass(ByteCountReducer.class);
    job.setNumReduceTasks(1);

    //job.setSortComparatorClass(LongWritable.DecreasingComparator.class);
    job.setOutputKeyClass(LongWritable.class);
    job.setOutputValueClass(Text.class);
    
    job.waitForCompletion(true);
    
    Job job2 = new Job(); 
    job2.setJarByClass(ByteCountDriver.class);
    job2.setMapperClass(SwitchMapper.class);
    job2.setSortComparatorClass(LongWritable.DecreasingComparator.class);
    FileInputFormat.addInputPath(job2, new Path(args[0]+"temp") );
    FileOutputFormat.setOutputPath(job2, new Path(args[1])  );
    
    boolean success = job2.waitForCompletion(true);
    FileSystem fs = FileSystem.get(new Configuration());
    // true stands for recursively deleting the folder you gave
    fs.delete(new Path(args[0]+"temp"), true);
    
    
    System.exit(success ? 0 : 1);
  }
}

