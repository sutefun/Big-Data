import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.junit.Test;

public class Split200Mapper extends Mapper<LongWritable, Text, IntWritable, Text> {

  @Override
  public void map(LongWritable key, Text value, Context context)
      throws IOException, InterruptedException {

	        String[] fields = value.toString().split(" ");
	        
	        if(fields.length >3){
	        	//get the last index minus one from the log line
		        String s = fields[fields.length - 2];
		        try{
		        	Integer status = Integer.parseInt(s);
			  		IntWritable httpstatus = new IntWritable( status );
			  		
			  		//write context
					context.write( httpstatus , value );
		        }catch (NumberFormatException nfe){
		        	
		        }
		        
	        }
	        
		

  }//end of map
}//end of mapper class
