import java.util.HashMap;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.conf.Configurable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.mapreduce.Partitioner;

public class Split200Partitioner extends Partitioner< IntWritable , Text> {

  private int partitionNumber(IntWritable val){
	  if(val.get() == 200 ){
		  return 0;
	  }
	  else{
		  return 1;
	  }
	  
  }

  public int getPartition( IntWritable key,Text value, int numReduceTasks) {
    return partitionNumber(key);
  }
}
