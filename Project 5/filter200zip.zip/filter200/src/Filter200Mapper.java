import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.junit.Test;

public class Filter200Mapper extends Mapper<LongWritable, Text, Text, IntWritable> {

	String tabb = "\t";
	
  @Override
  public void map(LongWritable key, Text value, Context context)
      throws IOException, InterruptedException {

	        String[] fields = value.toString().split("\\s+");
	        
	      //10.223.157.186 - - [15/Jul/2009:15:50:51 -0700] "GET /assets/img/dummy/secondary-news-3.jpg HTTP/1.1" 304 -
        	
	        if(fields.length >3){
	        	
	        	
		        String uri = fields[6];		// /assets/img/dummy/secondary-news-3.jpg
		        String status = fields[8];	// 304
		        
		        String[] fields2 = uri.split("/");
		        
		        if(fields2.length >0 ){
		        	// /assets/img/dummy/secondary-news-3.jpg
		        	
		        	String filename = fields2[ fields2.length-1 ];		// secondary-news-3.jpg 
		        														// \ displaytitle.php?id=10
		        	if(filename.contains(".")){
		        		String fields3[] = filename.split("\\.");;
			        	
			        	
			        	// /secondary-news-3.jpg
			        	// atau
			        	// /blabla
			        	
			        	if(fields3.length>0){
			        		// displaytitle.php?id=10
				        	// atau
			        		// secondary-news-3.jpg
			        		
			        		String extension = fields3[ fields3.length - 1 ];
			        		String fields4[] = extension.split("\\W+");
			        		
			        		if(fields4.length > 1 ){ //not extension : displaytitle.php?id=10
			        			context.write(new Text(uri +tabb + "-" +tabb+ status) , new IntWritable(1) );
			        			
			        		}
			        		else{
			        			context.write(new Text(uri +tabb+ extension +tabb + status) , new IntWritable(1) );
			        			
			        		}
			        		
			        		
			        	}
			        	else{
			        		context.write(new Text(uri +tabb + "-" + tabb + status) , new IntWritable(1) );
			        	}
			        	
		        	}
		        	else{
		        		context.write(new Text(uri +tabb+"-" +tabb + status) , new IntWritable(1) );
		        	}
		        	
		        }
		        else{
		        	
		        	context.write(new Text(uri +tabb+"-" +tabb + status) , new IntWritable(1) );
		        	
		        }
		        	
	        }
	        
		

  }//end of map
}//end of mapper class
